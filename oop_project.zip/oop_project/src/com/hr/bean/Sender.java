package com.hr.bean;

public class Sender {
   
    private String Send_Phone;
    private int Send_id;
    private String Send_Name;
    private String Send_email;
    private String Send_city;
    private String Send_Address;
    
    public String getSend_Phone() {
        return Send_Phone;
    }
    
    public void setSend_Phone(String send_Phone) {
        this.Send_Phone = send_Phone;
    }
    
    public int getSend_id() {
        return Send_id;
    }
    
    public void setSend_id(int send_id) {
        this.Send_id = send_id;
    }
    
    public String getSend_Name() {
        return Send_Name;
    }
    
    public void setSend_Name(String send_Name) {
        this.Send_Name = send_Name;
    }
    
    public String getSend_email() {
        return Send_email;
    }
    
    public void setSend_email(String send_email) {
        this.Send_email = send_email;
    }
    
    public String getSend_city() {
        return Send_city;
    }
    
    public void setSend_city(String send_city) {
        this.Send_city = send_city;
    }
    
    public String getSend_Address() {
        return Send_Address;
    }
    
    public void setSend_Address(String send_Address) {
        this.Send_Address = send_Address;
    }
}
