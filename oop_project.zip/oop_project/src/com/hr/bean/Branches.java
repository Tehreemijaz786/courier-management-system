package com.hr.bean;

public class Branches {
	private int Charges;
    private int Distance;
   private String City;
public int getCharges() {
	return Charges;
}
public void setCharges(int charges) {
	Charges = charges;
}
public int getDistance() {
	return Distance;
}
public void setDistance(int distance) {
	Distance = distance;
}
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}
   
   
}
