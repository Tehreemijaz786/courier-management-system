package com.hr.bean;

public class Receiver {

    private int rec_id;
    private String rec_name;
    private String rec_address;
    private String rec_phone;
    private int rec_cnic;
    private String rec_email;
    private String rec_city;

    public int getRec_id() {
        return rec_id;
    }

    public void setRec_id(int rec_id) {
        this.rec_id = rec_id;
    }

    public String getRec_name() {
        return rec_name;
    }

    public void setRec_name(String rec_name) {
        this.rec_name = rec_name;
    }

    public String getRec_address() {
        return rec_address;
    }

    public void setRec_address(String rec_address) {
        this.rec_address = rec_address;
    }

    public String getRec_phone() {
        return rec_phone;
    }

    public void setRec_phone(String rec_phone) {
        this.rec_phone = rec_phone;
    }

    public int getRec_cnic() {
        return rec_cnic;
    }

    public void setRec_cnic(int rec_cnic) {
        this.rec_cnic = rec_cnic;
    }

    public String getRec_email() {
        return rec_email;
    }

    public void setRec_email(String rec_email) {
        this.rec_email = rec_email;
    }

    public String getRec_city() {
        return rec_city;
    }

    public void setRec_city(String rec_city) {
        this.rec_city = rec_city;
    }
}
